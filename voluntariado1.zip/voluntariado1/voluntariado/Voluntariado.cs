﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Xml;
namespace voluntariado
{
    public partial class Voluntariado : Form
    {
        public static ColUtilizador Users = new ColUtilizador();
        private bool mouseDown;
        private Point lastLocation;

        public Voluntariado()
        {
            InitializeComponent();
            verifAll();
            CarregarList();
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            mouseDown = true;
            lastLocation = e.Location;

        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseDown)
            {
                this.Location = new Point(
                    (this.Location.X - lastLocation.X) + e.X, (this.Location.Y - lastLocation.Y) + e.Y);

                this.Update();
            }
        }

        private void criarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CriarUtilizador crUt = new CriarUtilizador();
            crUt.ShowDialog();
            lsvUsers.Items.Clear();
            CarregarList();
        }

        private void editarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (lsvUsers.SelectedItems.Count >= 1)
            {
                EditarDados edUt = new EditarDados(Convert.ToInt32(lsvUsers.Items[lsvUsers.SelectedIndices[0]].SubItems[1].Text));
                edUt.ShowDialog();
            }
        }

        private void bttTeste_Click(object sender, EventArgs e)
        {
            string texto = "";
            foreach (Utilizador x in Users)
            {
                texto += "\n" + x.Nome;
            }
            MessageBox.Show(texto);
        }
        #region Funções
        public static void AddXml(Utilizador user)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load("Contas.xml");

            XmlNode User = doc.CreateElement("User");
            XmlAttribute NIF = doc.CreateAttribute("NIF");
            XmlNode IRS = doc.CreateElement("IRS");
            XmlNode Nome = doc.CreateElement("Nome");
            XmlNode Localidade = doc.CreateElement("Localidade");
            XmlNode Morada = doc.CreateElement("Morada");
            XmlNode CodigoPostal = doc.CreateElement("CodigoPostal");
            XmlNode Contacto = doc.CreateElement("Contacto");
            XmlNode Email = doc.CreateElement("Email");
            XmlNode WhatsApp = doc.CreateElement("WhatsApp");
            XmlNode Tipo = doc.CreateElement("Tipo");
            XmlNode Password = doc.CreateElement("Password");

            NIF.Value = user.NIF.ToString();
            User.Attributes.Append(NIF);

            IRS.InnerText = user.IRS.ToString();
            User.AppendChild(IRS);

            Nome.InnerText = user.Nome;
            User.AppendChild(Nome);

            Localidade.InnerText = user.Localidade;
            User.AppendChild(Localidade);

            Morada.InnerText = user.Morada;
            User.AppendChild(Morada);

            Contacto.InnerText = user.Contacto;
            User.AppendChild(Contacto);

            CodigoPostal.InnerText = user.CodigoPostal;
            User.AppendChild(CodigoPostal);

            Email.InnerText = user.Email;
            User.AppendChild(Email);

            WhatsApp.InnerText = user.WhatsApp;
            User.AppendChild(WhatsApp);

            Password.InnerText = user.Password;
            User.AppendChild(Password);

            Tipo.InnerText = user.Tipo;
            User.AppendChild(Tipo); 

            doc.DocumentElement.AppendChild(User);
            doc.Save("Contas.xml");
        }
        public void organizaLista()
        {
            XmlDocument users = new XmlDocument();
            users.Load("Contas.xml");

            foreach (XmlNode node in users.DocumentElement)
            {
                Utilizador user = new Utilizador();
                foreach (XmlNode child in node.ChildNodes)
                {
                    switch (child.Name)
                    {
                        case "NIF":
                            user.NIF = Convert.ToInt32(child.InnerText);
                            break;
                        case "IRS":
                            user.IRS = Convert.ToInt32(child.InnerText);
                            break;
                        case "Nome":
                            user.Nome = child.InnerText.ToString();
                            break;
                        case "Localidade":
                            user.Localidade = child.InnerText.ToString();
                            break;
                        case "Morada":
                            user.Morada = child.InnerText.ToString();
                            break;
                        case "CodigoPostal":
                            user.CodigoPostal = child.InnerText.ToString();
                            break;
                        case "Email":
                            user.Email = child.InnerText.ToString();
                            break;

                        case "Contacto":
                            user.Contacto = child.InnerText.ToString();
                            break;

                        case "WhatsApp":
                            user.WhatsApp = child.InnerText.ToString();
                            break;

                        case "Tipo":
                            user.Tipo = child.InnerText.ToString();
                            break;

                        case "Password":
                            user.Password = child.InnerText.ToString();
                            break;
                    }
                }
                Users.AdicionarUtilizador(user);
            }
        }
        
        public void verifAll()
        {
            if (!File.Exists("Contas.xml"))
            {
                XmlWriterSettings settings = new XmlWriterSettings();
                settings.Indent = true;
                XmlWriter writer = XmlWriter.Create("Contas.xml", settings);
                writer.WriteStartDocument();
                writer.WriteComment("Contas dos utilizadores");
                writer.WriteStartElement("Contas");
                writer.WriteEndDocument();
                writer.Close();
            }
            else
            {
                organizaLista();
            }
        }

        public void CarregarList()
        {
            string nome;
            int nif;
            string localidade;
            string email;
            string contacto;
            double irs;
            string codigo;
            string morada;
            string what;
            string tipo;
            foreach (Utilizador user in Users)
            {
                nome = user.Nome;
                nif = user.NIF;
                localidade = user.Localidade;
                email = user.Localidade;
                contacto = user.Contacto;
                irs = user.IRS;
                codigo = user.CodigoPostal;
                morada = user.Morada;
                what = user.WhatsApp;
                tipo = user.Tipo;
                ListViewItem item = new ListViewItem();
                item.Text = nome;
                item.SubItems.Add(nif.ToString());
                item.SubItems.Add(email);
                item.SubItems.Add(irs.ToString());

                item.SubItems.Add(contacto);
                item.SubItems.Add(morada);
                item.SubItems.Add(codigo);
                item.SubItems.Add(localidade);
                item.SubItems.Add(what);
                item.SubItems.Add(tipo);

                lsvUsers.Items.Add(item);
            }
        }
        #endregion

        private void registarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RegistarPedido pedido = new RegistarPedido();
            pedido.Show();
        }
    }
}
