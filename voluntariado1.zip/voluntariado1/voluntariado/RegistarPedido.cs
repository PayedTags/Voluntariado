﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace voluntariado
{
    public partial class RegistarPedido : Form
    {
        public int count = 0;
        public RegistarPedido()
        {
            InitializeComponent();
            CarregarList();
        }

        public void CarregarList()
        {
            string nome;
            int nif;
            string localidade;
            string email;
            string contacto;
            foreach(Utilizador user in Voluntariado.Users)
            {
                if(user.Tipo == "Voluntario")
                {
                    nome = user.Nome;
                    nif = user.NIF;
                    localidade = user.Localidade;
                    email = user.Localidade;
                    contacto = user.Contacto;

                    ListViewItem item = new ListViewItem();
                    item.Text = nome;
                    item.SubItems.Add(nif.ToString());
                    item.SubItems.Add(localidade);
                    item.SubItems.Add(contacto);
                    item.SubItems.Add(email);

                    lstVoluntarios.Items.Add(item);
                    
                }
            }
        }

        private void bttEnviar_Click(object sender, EventArgs e)
        {
            Pedido pedido;
            string categoria;
            string local;
            DateTime Data;
            DateTime Hora;
            string Descrição;
            try
            {
                if (lstVoluntarios.SelectedItems.Count >= 1)
                {
                    categoria = tbxCategoria.Text;
                    local = tbxLocal.Text;
                    Data = dateTimePicker1.Value;
                    Hora = dateTimePicker2.Value;
                    pedido = new Pedido();
                    Categoria categoria1 = new Categoria();
                    categoria1.Codigo = count;
                    categoria1.Designação = categoria;
                    categoria1.Tipo = categoria;
                    pedido.Categorias = categoria1;
                    pedido.Local = local;
                    pedido.DataPedido = Data;
                }
            }
            catch
            {

            }
        }
    }
}
