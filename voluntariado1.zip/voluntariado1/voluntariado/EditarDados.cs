﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace voluntariado
{
    public partial class EditarDados : Form
    {
        public Utilizador User;
        public int nif;
        public EditarDados(int NIF)
        {
            InitializeComponent();
            tbxPassword.PasswordChar = '●';
            tbxPassword2.PasswordChar = '●';
            carregaItems(NIF);
            nif = NIF;
        }

        private void cbxShowChar_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxShowChar.Checked)
                tbxPassword.PasswordChar = '\0';
            else
                tbxPassword.PasswordChar = '●';
        }

        private void cbxShowChar2_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxShowChar2.Checked)
                tbxPassword2.PasswordChar = '\0';
            else
                tbxPassword2.PasswordChar = '●';
        }

        private void bttGuardar_Click(object sender, EventArgs e)
        {
            int IRS;
            string Nome;
            string Localidade;
            string Morada;
            string CodigoPostal;
            string Contacto;
            string Email;
            string WhatsApp;
            string Tipo;
            string Password;
            try
            {
                erpError.Clear();
                erpCerto.Clear();
                foreach (Utilizador x in Voluntariado.Users)
                {
                   if(x.NIF == nif)
                    {
                        User = x;
                        Voluntariado.Users.RemoverUtilizador(x);
                        break;
                    }
                }
                    

                if (verifEmpety())
                {
                    IRS = Convert.ToInt32(tbxIRS.Text);
                    Nome = tbxNome.Text;
                    Localidade = tbxLocalidade.Text;
                    Morada = tbxMorada.Text;
                    CodigoPostal = tbxCodigoPostal.Text;
                    Contacto = tbxContacto.Text;
                    Email = tbxEmail.Text;
                    WhatsApp = tbxWhatsApp.Text;
                    Password = tbxPassword.Text;
                    Tipo = cbxTipo.Text;


                    User.IRS = IRS;
                    User.Nome = Nome;
                    User.Localidade = Localidade;
                    User.Morada = Morada;
                    User.CodigoPostal = CodigoPostal;
                    User.Contacto = Contacto;
                    User.Email = Email;
                    User.WhatsApp = WhatsApp;
                    User.Password = Password;
                    User.Tipo = Tipo;

                    if (verifNome(tbxNome.Text))
                        if (Voluntariado.Users.AdicionarUtilizador(User))
                        {
                            removeUserXML(User.NIF);
                            Voluntariado.AddXml(User);
                        }
                        else
                        {
                            MessageBox.Show("Utilizador Ja Existe!!", "Erro: utilizador repetido", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    else
                        erpError.SetError(tbxNome, "Neste campo só pode conter [espaços, hifens, letras]");
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void carregaItems(int NIF)
        { 
            double IRS = 0;
            string Nome = "";
            string Localidade = "";
            string Morada = "";
            string CodigoPostal = "";
            string Contacto = "";
            string Email = "";
            string WhatsApp = "";
            string Tipo = "";
            string Password = "";
            foreach (Utilizador x in Voluntariado.Users)
            {
                if(x.NIF == NIF)
                {
                    IRS = x.IRS;
                    Nome = x.Nome;
                    Localidade = x.Localidade;
                    Morada = x.Morada;
                    CodigoPostal = x.CodigoPostal;
                    Email = x.Email;
                    Contacto = x.Contacto;
                    WhatsApp = x.WhatsApp;
                    Tipo = x.Tipo;
                    Password = x.Password;
                }
            }

            tbxIRS.Text = IRS.ToString();
            tbxNome.Text = Nome;
            tbxLocalidade.Text = Localidade;
            tbxMorada.Text = Morada;
            tbxCodigoPostal.Text = CodigoPostal;
            tbxContacto.Text = Contacto;
            tbxEmail.Text = Email;
            tbxWhatsApp.Text = WhatsApp;
            tbxPassword.Text = Password;
            tbxPassword2.Text = Password;
            cbxTipo.Text = Tipo;
        }

        public void removeUserXML(int nif)
        {
            XmlDocument users = new XmlDocument();
            users.Load("Contas.xml");
            XmlAttribute NIF = users.CreateAttribute("NIF");
            NIF.Value = nif.ToString();
            foreach(XmlNode node in users.DocumentElement)
            {
                if(node.Attributes.ToString() == NIF.Value)
                {
                    users.RemoveChild(node);
                }
            }
            users.Save("Contas.xml");
        }

        public bool verifEmpety()
        {
            if (tbxCodigoPostal.Text == "" || tbxNome.Text == "" ||  tbxIRS.Text == "" || tbxMorada.Text == "" || tbxEmail.Text == ""
                || tbxWhatsApp.Text == "" || tbxPassword.Text == "" || tbxLocalidade.Text == "" || tbxContacto.Text == "")
            {
                if (tbxCodigoPostal.Text == "")
                    erpError.SetError(tbxCodigoPostal, "Error: caixa esta vazia");
                else
                    erpCerto.SetError(tbxCodigoPostal, "Certo");

                if (tbxNome.Text == "")
                    erpError.SetError(tbxNome, "Error: caixa esta vazia");
                else
                    erpCerto.SetError(tbxNome, "Certo");

                if (tbxIRS.Text == "")
                    erpError.SetError(tbxIRS, "Error: caixa esta vazia");
                else
                    erpCerto.SetError(tbxIRS, "Certo");

                if (tbxMorada.Text == "")
                    erpError.SetError(tbxMorada, "Error: caixa esta vazia");
                else
                    erpCerto.SetError(tbxMorada, "Certo");

                if (tbxEmail.Text == "")
                    erpError.SetError(tbxEmail, "Error: caixa esta vazia");
                else
                    erpCerto.SetError(tbxEmail, "Certo");

                if (tbxWhatsApp.Text == "")
                    erpError.SetError(tbxWhatsApp, "Error: caixa esta vazia");
                else
                    erpCerto.SetError(tbxWhatsApp, "Certo");

                if (tbxPassword.Text == "")
                    erpError.SetError(tbxPassword, "Error: caixa esta vazia");
                else
                    erpCerto.SetError(tbxPassword, "Certo");

                if (tbxLocalidade.Text == "")
                    erpError.SetError(tbxLocalidade, "Error: caixa esta vazia");
                else
                    erpCerto.SetError(tbxLocalidade, "Certo");

                if (tbxContacto.Text == "")
                    erpError.SetError(tbxContacto, "Error: caixa esta vazia");
                else
                    erpCerto.SetError(tbxContacto, "Certo");
                return false;
            }
            return true;
        }

        public bool verifNome(string nome)
        {

            for (int i = 0; i < nome.Length; i++)
            {
                if (!char.IsLetter(nome[i]) && !char.IsWhiteSpace(nome[i]) && nome[i] != '-')
                {
                    return false;
                }
            }

            return true;
        }
    }
}
