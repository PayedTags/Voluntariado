﻿namespace voluntariado
{
    partial class EditarDados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EditarDados));
            this.bttGuardar = new System.Windows.Forms.Button();
            this.lbPassword = new System.Windows.Forms.Label();
            this.cbxShowChar = new System.Windows.Forms.CheckBox();
            this.tbxPassword = new System.Windows.Forms.TextBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.lbIRS = new System.Windows.Forms.Label();
            this.tbxIRS = new System.Windows.Forms.TextBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.lbWhatsApp = new System.Windows.Forms.Label();
            this.tbxWhatsApp = new System.Windows.Forms.TextBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.lbEmail = new System.Windows.Forms.Label();
            this.tbxEmail = new System.Windows.Forms.TextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.lbContacto = new System.Windows.Forms.Label();
            this.tbxContacto = new System.Windows.Forms.TextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.lbCodigoPostal = new System.Windows.Forms.Label();
            this.tbxCodigoPostal = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lbMorada = new System.Windows.Forms.Label();
            this.tbxMorada = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lbLocalidade = new System.Windows.Forms.Label();
            this.tbxLocalidade = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lbNome = new System.Windows.Forms.Label();
            this.tbxNome = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbEditarDados = new System.Windows.Forms.Label();
            this.lbConfirmPass = new System.Windows.Forms.Label();
            this.cbxShowChar2 = new System.Windows.Forms.CheckBox();
            this.tbxPassword2 = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbTipo = new System.Windows.Forms.Label();
            this.cbxTipo = new System.Windows.Forms.ComboBox();
            this.erpError = new System.Windows.Forms.ErrorProvider(this.components);
            this.erpCerto = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.erpError)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.erpCerto)).BeginInit();
            this.SuspendLayout();
            // 
            // bttGuardar
            // 
            this.bttGuardar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.bttGuardar.BackColor = System.Drawing.Color.Chocolate;
            this.bttGuardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttGuardar.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttGuardar.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.bttGuardar.Location = new System.Drawing.Point(589, 410);
            this.bttGuardar.Name = "bttGuardar";
            this.bttGuardar.Size = new System.Drawing.Size(128, 38);
            this.bttGuardar.TabIndex = 127;
            this.bttGuardar.Text = "Guardar";
            this.bttGuardar.UseVisualStyleBackColor = false;
            this.bttGuardar.Click += new System.EventHandler(this.bttGuardar_Click);
            // 
            // lbPassword
            // 
            this.lbPassword.AutoSize = true;
            this.lbPassword.BackColor = System.Drawing.Color.Transparent;
            this.lbPassword.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPassword.ForeColor = System.Drawing.Color.Gray;
            this.lbPassword.Location = new System.Drawing.Point(231, 331);
            this.lbPassword.Name = "lbPassword";
            this.lbPassword.Size = new System.Drawing.Size(67, 18);
            this.lbPassword.TabIndex = 125;
            this.lbPassword.Text = "Password";
            // 
            // cbxShowChar
            // 
            this.cbxShowChar.AutoSize = true;
            this.cbxShowChar.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxShowChar.Location = new System.Drawing.Point(212, 393);
            this.cbxShowChar.Name = "cbxShowChar";
            this.cbxShowChar.Size = new System.Drawing.Size(104, 17);
            this.cbxShowChar.TabIndex = 124;
            this.cbxShowChar.Text = "Show characters";
            this.cbxShowChar.UseVisualStyleBackColor = true;
            this.cbxShowChar.CheckedChanged += new System.EventHandler(this.cbxShowChar_CheckedChanged);
            // 
            // tbxPassword
            // 
            this.tbxPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxPassword.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxPassword.Location = new System.Drawing.Point(106, 360);
            this.tbxPassword.Name = "tbxPassword";
            this.tbxPassword.Size = new System.Drawing.Size(290, 24);
            this.tbxPassword.TabIndex = 123;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel9.Location = new System.Drawing.Point(106, 386);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(317, 1);
            this.panel9.TabIndex = 122;
            // 
            // lbIRS
            // 
            this.lbIRS.AutoSize = true;
            this.lbIRS.BackColor = System.Drawing.Color.Transparent;
            this.lbIRS.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbIRS.ForeColor = System.Drawing.Color.Gray;
            this.lbIRS.Location = new System.Drawing.Point(251, 154);
            this.lbIRS.Name = "lbIRS";
            this.lbIRS.Size = new System.Drawing.Size(27, 18);
            this.lbIRS.TabIndex = 121;
            this.lbIRS.Text = "IRS";
            // 
            // tbxIRS
            // 
            this.tbxIRS.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxIRS.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxIRS.Location = new System.Drawing.Point(106, 175);
            this.tbxIRS.Name = "tbxIRS";
            this.tbxIRS.Size = new System.Drawing.Size(290, 24);
            this.tbxIRS.TabIndex = 120;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel10.Location = new System.Drawing.Point(106, 201);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(317, 1);
            this.panel10.TabIndex = 119;
            // 
            // lbWhatsApp
            // 
            this.lbWhatsApp.AutoSize = true;
            this.lbWhatsApp.BackColor = System.Drawing.Color.Transparent;
            this.lbWhatsApp.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbWhatsApp.ForeColor = System.Drawing.Color.Gray;
            this.lbWhatsApp.Location = new System.Drawing.Point(617, 270);
            this.lbWhatsApp.Name = "lbWhatsApp";
            this.lbWhatsApp.Size = new System.Drawing.Size(72, 18);
            this.lbWhatsApp.TabIndex = 118;
            this.lbWhatsApp.Text = "WhatsApp";
            // 
            // tbxWhatsApp
            // 
            this.tbxWhatsApp.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxWhatsApp.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxWhatsApp.Location = new System.Drawing.Point(495, 291);
            this.tbxWhatsApp.Name = "tbxWhatsApp";
            this.tbxWhatsApp.Size = new System.Drawing.Size(290, 24);
            this.tbxWhatsApp.TabIndex = 117;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel8.Location = new System.Drawing.Point(495, 317);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(317, 1);
            this.panel8.TabIndex = 116;
            // 
            // lbEmail
            // 
            this.lbEmail.AutoSize = true;
            this.lbEmail.BackColor = System.Drawing.Color.Transparent;
            this.lbEmail.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbEmail.ForeColor = System.Drawing.Color.Gray;
            this.lbEmail.Location = new System.Drawing.Point(243, 213);
            this.lbEmail.Name = "lbEmail";
            this.lbEmail.Size = new System.Drawing.Size(42, 18);
            this.lbEmail.TabIndex = 115;
            this.lbEmail.Text = "Email";
            // 
            // tbxEmail
            // 
            this.tbxEmail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxEmail.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxEmail.Location = new System.Drawing.Point(106, 234);
            this.tbxEmail.Name = "tbxEmail";
            this.tbxEmail.Size = new System.Drawing.Size(290, 24);
            this.tbxEmail.TabIndex = 114;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel7.Location = new System.Drawing.Point(106, 260);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(317, 1);
            this.panel7.TabIndex = 113;
            // 
            // lbContacto
            // 
            this.lbContacto.AutoSize = true;
            this.lbContacto.BackColor = System.Drawing.Color.Transparent;
            this.lbContacto.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbContacto.ForeColor = System.Drawing.Color.Gray;
            this.lbContacto.Location = new System.Drawing.Point(233, 272);
            this.lbContacto.Name = "lbContacto";
            this.lbContacto.Size = new System.Drawing.Size(63, 18);
            this.lbContacto.TabIndex = 112;
            this.lbContacto.Text = "Contacto";
            // 
            // tbxContacto
            // 
            this.tbxContacto.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxContacto.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxContacto.Location = new System.Drawing.Point(106, 293);
            this.tbxContacto.Name = "tbxContacto";
            this.tbxContacto.Size = new System.Drawing.Size(290, 24);
            this.tbxContacto.TabIndex = 111;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel6.Location = new System.Drawing.Point(106, 319);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(317, 1);
            this.panel6.TabIndex = 110;
            // 
            // lbCodigoPostal
            // 
            this.lbCodigoPostal.AutoSize = true;
            this.lbCodigoPostal.BackColor = System.Drawing.Color.Transparent;
            this.lbCodigoPostal.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCodigoPostal.ForeColor = System.Drawing.Color.Gray;
            this.lbCodigoPostal.Location = new System.Drawing.Point(607, 151);
            this.lbCodigoPostal.Name = "lbCodigoPostal";
            this.lbCodigoPostal.Size = new System.Drawing.Size(92, 18);
            this.lbCodigoPostal.TabIndex = 109;
            this.lbCodigoPostal.Text = "Codigo Postal";
            // 
            // tbxCodigoPostal
            // 
            this.tbxCodigoPostal.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxCodigoPostal.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxCodigoPostal.Location = new System.Drawing.Point(495, 172);
            this.tbxCodigoPostal.Name = "tbxCodigoPostal";
            this.tbxCodigoPostal.Size = new System.Drawing.Size(290, 24);
            this.tbxCodigoPostal.TabIndex = 108;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel5.Location = new System.Drawing.Point(495, 198);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(317, 1);
            this.panel5.TabIndex = 107;
            // 
            // lbMorada
            // 
            this.lbMorada.AutoSize = true;
            this.lbMorada.BackColor = System.Drawing.Color.Transparent;
            this.lbMorada.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMorada.ForeColor = System.Drawing.Color.Gray;
            this.lbMorada.Location = new System.Drawing.Point(626, 94);
            this.lbMorada.Name = "lbMorada";
            this.lbMorada.Size = new System.Drawing.Size(55, 18);
            this.lbMorada.TabIndex = 106;
            this.lbMorada.Text = "Morada";
            // 
            // tbxMorada
            // 
            this.tbxMorada.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxMorada.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxMorada.Location = new System.Drawing.Point(495, 115);
            this.tbxMorada.Name = "tbxMorada";
            this.tbxMorada.Size = new System.Drawing.Size(290, 24);
            this.tbxMorada.TabIndex = 105;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel4.Location = new System.Drawing.Point(495, 141);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(317, 1);
            this.panel4.TabIndex = 104;
            // 
            // lbLocalidade
            // 
            this.lbLocalidade.AutoSize = true;
            this.lbLocalidade.BackColor = System.Drawing.Color.Transparent;
            this.lbLocalidade.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLocalidade.ForeColor = System.Drawing.Color.Gray;
            this.lbLocalidade.Location = new System.Drawing.Point(616, 211);
            this.lbLocalidade.Name = "lbLocalidade";
            this.lbLocalidade.Size = new System.Drawing.Size(74, 18);
            this.lbLocalidade.TabIndex = 103;
            this.lbLocalidade.Text = "Localidade";
            // 
            // tbxLocalidade
            // 
            this.tbxLocalidade.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxLocalidade.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxLocalidade.Location = new System.Drawing.Point(495, 232);
            this.tbxLocalidade.Name = "tbxLocalidade";
            this.tbxLocalidade.Size = new System.Drawing.Size(290, 24);
            this.tbxLocalidade.TabIndex = 102;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel3.Location = new System.Drawing.Point(495, 258);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(317, 1);
            this.panel3.TabIndex = 101;
            // 
            // lbNome
            // 
            this.lbNome.AutoSize = true;
            this.lbNome.BackColor = System.Drawing.Color.Transparent;
            this.lbNome.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNome.ForeColor = System.Drawing.Color.Gray;
            this.lbNome.Location = new System.Drawing.Point(241, 94);
            this.lbNome.Name = "lbNome";
            this.lbNome.Size = new System.Drawing.Size(46, 18);
            this.lbNome.TabIndex = 100;
            this.lbNome.Text = "Nome";
            // 
            // tbxNome
            // 
            this.tbxNome.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxNome.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxNome.Location = new System.Drawing.Point(106, 115);
            this.tbxNome.Name = "tbxNome";
            this.tbxNome.Size = new System.Drawing.Size(290, 24);
            this.tbxNome.TabIndex = 98;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel2.Location = new System.Drawing.Point(106, 141);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(317, 1);
            this.panel2.TabIndex = 97;
            // 
            // lbEditarDados
            // 
            this.lbEditarDados.AutoSize = true;
            this.lbEditarDados.Font = new System.Drawing.Font("Calibri", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbEditarDados.ForeColor = System.Drawing.Color.Chocolate;
            this.lbEditarDados.Location = new System.Drawing.Point(326, 9);
            this.lbEditarDados.Name = "lbEditarDados";
            this.lbEditarDados.Size = new System.Drawing.Size(260, 45);
            this.lbEditarDados.TabIndex = 131;
            this.lbEditarDados.Text = "Editar Utilizador";
            // 
            // lbConfirmPass
            // 
            this.lbConfirmPass.AutoSize = true;
            this.lbConfirmPass.BackColor = System.Drawing.Color.Transparent;
            this.lbConfirmPass.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbConfirmPass.ForeColor = System.Drawing.Color.Gray;
            this.lbConfirmPass.Location = new System.Drawing.Point(199, 419);
            this.lbConfirmPass.Name = "lbConfirmPass";
            this.lbConfirmPass.Size = new System.Drawing.Size(131, 18);
            this.lbConfirmPass.TabIndex = 135;
            this.lbConfirmPass.Text = "Confirmar Password";
            // 
            // cbxShowChar2
            // 
            this.cbxShowChar2.AutoSize = true;
            this.cbxShowChar2.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxShowChar2.Location = new System.Drawing.Point(212, 481);
            this.cbxShowChar2.Name = "cbxShowChar2";
            this.cbxShowChar2.Size = new System.Drawing.Size(104, 17);
            this.cbxShowChar2.TabIndex = 134;
            this.cbxShowChar2.Text = "Show characters";
            this.cbxShowChar2.UseVisualStyleBackColor = true;
            this.cbxShowChar2.CheckedChanged += new System.EventHandler(this.cbxShowChar2_CheckedChanged);
            // 
            // tbxPassword2
            // 
            this.tbxPassword2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxPassword2.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxPassword2.Location = new System.Drawing.Point(106, 448);
            this.tbxPassword2.Name = "tbxPassword2";
            this.tbxPassword2.Size = new System.Drawing.Size(290, 24);
            this.tbxPassword2.TabIndex = 133;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel1.Location = new System.Drawing.Point(106, 474);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(317, 1);
            this.panel1.TabIndex = 132;
            // 
            // lbTipo
            // 
            this.lbTipo.AutoSize = true;
            this.lbTipo.BackColor = System.Drawing.Color.Transparent;
            this.lbTipo.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTipo.ForeColor = System.Drawing.Color.Gray;
            this.lbTipo.Location = new System.Drawing.Point(636, 333);
            this.lbTipo.Name = "lbTipo";
            this.lbTipo.Size = new System.Drawing.Size(35, 18);
            this.lbTipo.TabIndex = 137;
            this.lbTipo.Text = "Tipo";
            // 
            // cbxTipo
            // 
            this.cbxTipo.BackColor = System.Drawing.Color.White;
            this.cbxTipo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxTipo.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxTipo.FormattingEnabled = true;
            this.cbxTipo.Items.AddRange(new object[] {
            "Voluntario",
            "Gestor",
            "Admin"});
            this.cbxTipo.Location = new System.Drawing.Point(495, 360);
            this.cbxTipo.Name = "cbxTipo";
            this.cbxTipo.Size = new System.Drawing.Size(317, 27);
            this.cbxTipo.TabIndex = 136;
            // 
            // erpError
            // 
            this.erpError.ContainerControl = this;
            this.erpError.Icon = ((System.Drawing.Icon)(resources.GetObject("erpError.Icon")));
            // 
            // erpCerto
            // 
            this.erpCerto.ContainerControl = this;
            this.erpCerto.Icon = ((System.Drawing.Icon)(resources.GetObject("erpCerto.Icon")));
            // 
            // EditarDados
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(918, 561);
            this.Controls.Add(this.lbTipo);
            this.Controls.Add(this.cbxTipo);
            this.Controls.Add(this.lbConfirmPass);
            this.Controls.Add(this.cbxShowChar2);
            this.Controls.Add(this.tbxPassword2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lbEditarDados);
            this.Controls.Add(this.bttGuardar);
            this.Controls.Add(this.lbPassword);
            this.Controls.Add(this.cbxShowChar);
            this.Controls.Add(this.tbxPassword);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.lbIRS);
            this.Controls.Add(this.tbxIRS);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.lbWhatsApp);
            this.Controls.Add(this.tbxWhatsApp);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.lbEmail);
            this.Controls.Add(this.tbxEmail);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.lbContacto);
            this.Controls.Add(this.tbxContacto);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.lbCodigoPostal);
            this.Controls.Add(this.tbxCodigoPostal);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.lbMorada);
            this.Controls.Add(this.tbxMorada);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.lbLocalidade);
            this.Controls.Add(this.tbxLocalidade);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.lbNome);
            this.Controls.Add(this.tbxNome);
            this.Controls.Add(this.panel2);
            this.Name = "EditarDados";
            this.Text = "EditarDados";
            ((System.ComponentModel.ISupportInitialize)(this.erpError)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.erpCerto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bttGuardar;
        private System.Windows.Forms.Label lbPassword;
        private System.Windows.Forms.CheckBox cbxShowChar;
        private System.Windows.Forms.TextBox tbxPassword;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label lbIRS;
        private System.Windows.Forms.TextBox tbxIRS;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label lbWhatsApp;
        private System.Windows.Forms.TextBox tbxWhatsApp;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label lbEmail;
        private System.Windows.Forms.TextBox tbxEmail;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label lbContacto;
        private System.Windows.Forms.TextBox tbxContacto;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label lbCodigoPostal;
        private System.Windows.Forms.TextBox tbxCodigoPostal;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lbMorada;
        private System.Windows.Forms.TextBox tbxMorada;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lbLocalidade;
        private System.Windows.Forms.TextBox tbxLocalidade;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lbNome;
        private System.Windows.Forms.TextBox tbxNome;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbEditarDados;
        private System.Windows.Forms.Label lbConfirmPass;
        private System.Windows.Forms.CheckBox cbxShowChar2;
        private System.Windows.Forms.TextBox tbxPassword2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbTipo;
        private System.Windows.Forms.ComboBox cbxTipo;
        private System.Windows.Forms.ErrorProvider erpError;
        private System.Windows.Forms.ErrorProvider erpCerto;
    }
}