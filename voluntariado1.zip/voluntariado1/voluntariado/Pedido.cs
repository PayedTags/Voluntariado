﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace voluntariado
{
    public class Pedido
    {
        #region PropriedadesAutomaticas
        public int Codigo { get; set; }
        public string Descrição { get; set; }
        public string Estado { get; set; }
        public string Local { get; set; }
        public string Avaliação { get; set; }
        public DateTime DataPedido { get; set; }
        public DateTime DataAtribuição { get; set; }
        public DateTime DataConclusão { get; set; }
        public DateTime HoraAtribuição { get; set; }
        public DateTime HoraConclusão { get; set; }
        public Utilizador Cliente { get; set; }
        public Utilizador Voluntario { get; set; }
        public Categoria Categorias { get; set; }
        #endregion


    }
}
