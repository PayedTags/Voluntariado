﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;


namespace voluntariado
{
    public partial class CriarUtilizador : Form
    {

        public Utilizador User;
        public ColUtilizador colUser = new ColUtilizador();
        public CriarUtilizador()
        {
            InitializeComponent();
            tbxPassword.PasswordChar = '●';
            erpCerto.BlinkRate = 0;
            erpError.BlinkRate = 0;
            cbxTipo.SelectedIndex = 0;
        }

        private void cbxShowChar_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxShowChar.Checked)
            {
                tbxPassword.PasswordChar = '\0';
            }
            else
            {
                tbxPassword.PasswordChar = '●';
            }
        }

        private void bttCriar_Click(object sender, EventArgs e)
        {
            int NIF;
            double IRS;
            string Nome;
            string Localidade;
            string Morada;
            string CodigoPostal;
            string Contacto;
            string Email;
            string WhatsApp;
            string Tipo;
            string Password;
            Regex Nomerx = new Regex(@"^[A-Z]+(([ -][A-Z])?[a-z]*)*$");
            Regex NIFrx = new Regex(@"(^[0-9]{9}$)");
            Regex Codigorx = new Regex(@"^([0-9]{4})-([0-9]{3})$");
            Regex Emailrx = new Regex(@"\w{1,}@\w{1,}\.\w{1,}");
            Regex WhatsApprx = new Regex(@"^[9]{1}\d{8}$");
            Regex Passwordrx = new Regex(@"^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$");






            try
            {
                erpError.Clear();
                erpCerto.Clear();
                User = new Utilizador();

                NIF = Convert.ToInt32(tbxNIF.Text);
                IRS = Convert.ToInt32(tbxIRS.Text);
                Nome = tbxNome.Text;
                Localidade = tbxLocalidade.Text;
                Morada = tbxMorada.Text;
                CodigoPostal = tbxCodigoPostal.Text;
                Contacto = tbxContacto.Text;
                Email = tbxEmail.Text;
                WhatsApp = tbxWhatsApp.Text;
                Password = tbxPassword.Text;
                Tipo = cbxTipo.Text;


                User.NIF = NIF;
                User.IRS = IRS;
                User.Nome = Nome;
                User.Localidade = Localidade;
                User.Morada = Morada;
                User.CodigoPostal = CodigoPostal;
                User.Contacto = Contacto;
                User.Email = Email;
                User.WhatsApp = WhatsApp;
                User.Password = Password;
                User.Tipo = Tipo;

                if (!Nomerx.IsMatch(tbxNome.Text))
                    erpError.SetError(tbxNome, "Nome Invalido");




                if (verifNome(tbxNome.Text))
                    if (Voluntariado.Users.AdicionarUtilizador(User))
                    {
                        Voluntariado.AddXml(User);
                    }
                    else
                    {
                        MessageBox.Show("Utilizador Ja Existe!!", "Erro: utilizador repetido", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                else
                    erpError.SetError(tbxNome, "Neste campo só pode conter [espaços, hifens, letras]");

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public bool verifNome(string nome)
        {

            for (int i = 0; i < nome.Length; i++)
            {
                if (!char.IsLetter(nome[i]) && !char.IsWhiteSpace(nome[i]) && nome[i] != '-')
                {
                    return false;
                }
            }

            return true;
        }
    }
}
