﻿namespace voluntariado
{
    partial class RegistarPedido
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstVoluntarios = new System.Windows.Forms.ListView();
            this.nome = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.NIF = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Localidade = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Contacto = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Email = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lbCategoria = new System.Windows.Forms.Label();
            this.tbxCategoria = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbDescrição = new System.Windows.Forms.Label();
            this.tbxDescricao = new System.Windows.Forms.TextBox();
            this.lbData = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.lbLocal = new System.Windows.Forms.Label();
            this.tbxLocal = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lbHora = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.bttEnviar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lstVoluntarios
            // 
            this.lstVoluntarios.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.nome,
            this.NIF,
            this.Localidade,
            this.Contacto,
            this.Email});
            this.lstVoluntarios.HideSelection = false;
            this.lstVoluntarios.Location = new System.Drawing.Point(534, 12);
            this.lstVoluntarios.MultiSelect = false;
            this.lstVoluntarios.Name = "lstVoluntarios";
            this.lstVoluntarios.Size = new System.Drawing.Size(505, 580);
            this.lstVoluntarios.TabIndex = 0;
            this.lstVoluntarios.UseCompatibleStateImageBehavior = false;
            this.lstVoluntarios.View = System.Windows.Forms.View.Details;
            // 
            // nome
            // 
            this.nome.Text = "Nome";
            // 
            // NIF
            // 
            this.NIF.Text = "NIF";
            // 
            // Localidade
            // 
            this.Localidade.Text = "Localidade";
            this.Localidade.Width = 93;
            // 
            // Contacto
            // 
            this.Contacto.Text = "Contacto";
            // 
            // Email
            // 
            this.Email.Text = "Email";
            // 
            // lbCategoria
            // 
            this.lbCategoria.AutoSize = true;
            this.lbCategoria.BackColor = System.Drawing.Color.Transparent;
            this.lbCategoria.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCategoria.ForeColor = System.Drawing.Color.Gray;
            this.lbCategoria.Location = new System.Drawing.Point(186, 15);
            this.lbCategoria.Name = "lbCategoria";
            this.lbCategoria.Size = new System.Drawing.Size(67, 18);
            this.lbCategoria.TabIndex = 66;
            this.lbCategoria.Text = "Categoria";
            // 
            // tbxCategoria
            // 
            this.tbxCategoria.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxCategoria.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxCategoria.Location = new System.Drawing.Point(60, 36);
            this.tbxCategoria.Name = "tbxCategoria";
            this.tbxCategoria.Size = new System.Drawing.Size(290, 24);
            this.tbxCategoria.TabIndex = 65;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel2.Location = new System.Drawing.Point(61, 62);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(317, 1);
            this.panel2.TabIndex = 64;
            // 
            // lbDescrição
            // 
            this.lbDescrição.AutoSize = true;
            this.lbDescrição.BackColor = System.Drawing.Color.Transparent;
            this.lbDescrição.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDescrição.ForeColor = System.Drawing.Color.Gray;
            this.lbDescrição.Location = new System.Drawing.Point(226, 209);
            this.lbDescrição.Name = "lbDescrição";
            this.lbDescrição.Size = new System.Drawing.Size(67, 18);
            this.lbDescrição.TabIndex = 69;
            this.lbDescrição.Text = "Descrição";
            // 
            // tbxDescricao
            // 
            this.tbxDescricao.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxDescricao.Location = new System.Drawing.Point(12, 230);
            this.tbxDescricao.Multiline = true;
            this.tbxDescricao.Name = "tbxDescricao";
            this.tbxDescricao.Size = new System.Drawing.Size(495, 285);
            this.tbxDescricao.TabIndex = 68;
            // 
            // lbData
            // 
            this.lbData.AutoSize = true;
            this.lbData.BackColor = System.Drawing.Color.Transparent;
            this.lbData.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbData.ForeColor = System.Drawing.Color.Gray;
            this.lbData.Location = new System.Drawing.Point(187, 143);
            this.lbData.Name = "lbData";
            this.lbData.Size = new System.Drawing.Size(36, 18);
            this.lbData.TabIndex = 72;
            this.lbData.Text = "Data";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(60, 168);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(290, 20);
            this.dateTimePicker1.TabIndex = 73;
            // 
            // lbLocal
            // 
            this.lbLocal.AutoSize = true;
            this.lbLocal.BackColor = System.Drawing.Color.Transparent;
            this.lbLocal.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLocal.ForeColor = System.Drawing.Color.Gray;
            this.lbLocal.Location = new System.Drawing.Point(200, 77);
            this.lbLocal.Name = "lbLocal";
            this.lbLocal.Size = new System.Drawing.Size(39, 18);
            this.lbLocal.TabIndex = 76;
            this.lbLocal.Text = "Local";
            // 
            // tbxLocal
            // 
            this.tbxLocal.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxLocal.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxLocal.Location = new System.Drawing.Point(60, 98);
            this.tbxLocal.Name = "tbxLocal";
            this.tbxLocal.Size = new System.Drawing.Size(290, 24);
            this.tbxLocal.TabIndex = 75;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel4.Location = new System.Drawing.Point(61, 124);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(317, 1);
            this.panel4.TabIndex = 74;
            // 
            // lbHora
            // 
            this.lbHora.AutoSize = true;
            this.lbHora.BackColor = System.Drawing.Color.Transparent;
            this.lbHora.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHora.ForeColor = System.Drawing.Color.Gray;
            this.lbHora.Location = new System.Drawing.Point(381, 143);
            this.lbHora.Name = "lbHora";
            this.lbHora.Size = new System.Drawing.Size(37, 18);
            this.lbHora.TabIndex = 78;
            this.lbHora.Text = "Hora";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dateTimePicker2.Location = new System.Drawing.Point(356, 168);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(86, 20);
            this.dateTimePicker2.TabIndex = 79;
            // 
            // bttEnviar
            // 
            this.bttEnviar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.bttEnviar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttEnviar.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttEnviar.ForeColor = System.Drawing.Color.White;
            this.bttEnviar.Location = new System.Drawing.Point(175, 538);
            this.bttEnviar.Name = "bttEnviar";
            this.bttEnviar.Size = new System.Drawing.Size(168, 54);
            this.bttEnviar.TabIndex = 80;
            this.bttEnviar.Text = "Enviar";
            this.bttEnviar.UseVisualStyleBackColor = false;
            this.bttEnviar.Click += new System.EventHandler(this.bttEnviar_Click);
            // 
            // RegistarPedido
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1051, 604);
            this.Controls.Add(this.bttEnviar);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.lbHora);
            this.Controls.Add(this.lbLocal);
            this.Controls.Add(this.tbxLocal);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.lbData);
            this.Controls.Add(this.lbDescrição);
            this.Controls.Add(this.tbxDescricao);
            this.Controls.Add(this.lbCategoria);
            this.Controls.Add(this.tbxCategoria);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.lstVoluntarios);
            this.Name = "RegistarPedido";
            this.Text = "RegistarPedido";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView lstVoluntarios;
        private System.Windows.Forms.Label lbCategoria;
        private System.Windows.Forms.TextBox tbxCategoria;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbDescrição;
        private System.Windows.Forms.TextBox tbxDescricao;
        private System.Windows.Forms.Label lbData;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label lbLocal;
        private System.Windows.Forms.TextBox tbxLocal;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lbHora;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Button bttEnviar;
        private System.Windows.Forms.ColumnHeader nome;
        private System.Windows.Forms.ColumnHeader NIF;
        private System.Windows.Forms.ColumnHeader Localidade;
        private System.Windows.Forms.ColumnHeader Contacto;
        private System.Windows.Forms.ColumnHeader Email;
    }
}