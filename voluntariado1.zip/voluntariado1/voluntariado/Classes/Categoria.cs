﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace voluntariado
{
    public class Categoria
    {
        #region PropriedadesAutomaticas
        public int Codigo { get; set; }
        public string Designação { get; set; }
        public string Tipo { get; set; }
        #endregion
    }
}
