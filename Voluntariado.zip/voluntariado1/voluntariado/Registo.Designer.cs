﻿namespace voluntariado
{
    partial class Registo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Registo));
            this.lbConfPassword = new System.Windows.Forms.Label();
            this.lbUser = new System.Windows.Forms.Label();
            this.cbxShowChar2 = new System.Windows.Forms.CheckBox();
            this.tbxPassword2 = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbSignIn = new System.Windows.Forms.Label();
            this.tbxUser = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbPassword = new System.Windows.Forms.Label();
            this.tbxPassword1 = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.cbxShowChar1 = new System.Windows.Forms.CheckBox();
            this.bttSignUp = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbConfPassword
            // 
            this.lbConfPassword.AutoSize = true;
            this.lbConfPassword.BackColor = System.Drawing.Color.Transparent;
            this.lbConfPassword.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbConfPassword.ForeColor = System.Drawing.Color.Gray;
            this.lbConfPassword.Location = new System.Drawing.Point(510, 419);
            this.lbConfPassword.Name = "lbConfPassword";
            this.lbConfPassword.Size = new System.Drawing.Size(119, 18);
            this.lbConfPassword.TabIndex = 67;
            this.lbConfPassword.Text = "Confirm Password";
            // 
            // lbUser
            // 
            this.lbUser.AutoSize = true;
            this.lbUser.BackColor = System.Drawing.Color.Transparent;
            this.lbUser.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbUser.ForeColor = System.Drawing.Color.Gray;
            this.lbUser.Location = new System.Drawing.Point(534, 243);
            this.lbUser.Name = "lbUser";
            this.lbUser.Size = new System.Drawing.Size(71, 18);
            this.lbUser.TabIndex = 66;
            this.lbUser.Text = "Username";
            // 
            // cbxShowChar2
            // 
            this.cbxShowChar2.AutoSize = true;
            this.cbxShowChar2.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxShowChar2.Location = new System.Drawing.Point(517, 481);
            this.cbxShowChar2.Name = "cbxShowChar2";
            this.cbxShowChar2.Size = new System.Drawing.Size(104, 17);
            this.cbxShowChar2.TabIndex = 64;
            this.cbxShowChar2.Text = "Show characters";
            this.cbxShowChar2.UseVisualStyleBackColor = true;
            this.cbxShowChar2.CheckedChanged += new System.EventHandler(this.cbxShowChar2_CheckedChanged);
            // 
            // tbxPassword2
            // 
            this.tbxPassword2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxPassword2.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxPassword2.Location = new System.Drawing.Point(411, 448);
            this.tbxPassword2.Name = "tbxPassword2";
            this.tbxPassword2.Size = new System.Drawing.Size(290, 24);
            this.tbxPassword2.TabIndex = 63;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel2.Location = new System.Drawing.Point(411, 474);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(317, 1);
            this.panel2.TabIndex = 62;
            // 
            // lbSignIn
            // 
            this.lbSignIn.AutoSize = true;
            this.lbSignIn.Font = new System.Drawing.Font("Calibri Light", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSignIn.ForeColor = System.Drawing.Color.Chocolate;
            this.lbSignIn.Location = new System.Drawing.Point(460, 59);
            this.lbSignIn.Name = "lbSignIn";
            this.lbSignIn.Size = new System.Drawing.Size(219, 78);
            this.lbSignIn.TabIndex = 61;
            this.lbSignIn.Text = "Sign up";
            // 
            // tbxUser
            // 
            this.tbxUser.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxUser.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxUser.Location = new System.Drawing.Point(411, 264);
            this.tbxUser.Name = "tbxUser";
            this.tbxUser.Size = new System.Drawing.Size(290, 24);
            this.tbxUser.TabIndex = 60;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel1.Location = new System.Drawing.Point(411, 290);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(317, 1);
            this.panel1.TabIndex = 59;
            // 
            // lbPassword
            // 
            this.lbPassword.AutoSize = true;
            this.lbPassword.BackColor = System.Drawing.Color.Transparent;
            this.lbPassword.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPassword.ForeColor = System.Drawing.Color.Gray;
            this.lbPassword.Location = new System.Drawing.Point(536, 324);
            this.lbPassword.Name = "lbPassword";
            this.lbPassword.Size = new System.Drawing.Size(67, 18);
            this.lbPassword.TabIndex = 72;
            this.lbPassword.Text = "Password";
            // 
            // tbxPassword1
            // 
            this.tbxPassword1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxPassword1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxPassword1.Location = new System.Drawing.Point(411, 353);
            this.tbxPassword1.Name = "tbxPassword1";
            this.tbxPassword1.Size = new System.Drawing.Size(290, 24);
            this.tbxPassword1.TabIndex = 71;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel3.Location = new System.Drawing.Point(411, 379);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(317, 1);
            this.panel3.TabIndex = 70;
            // 
            // cbxShowChar1
            // 
            this.cbxShowChar1.AutoSize = true;
            this.cbxShowChar1.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxShowChar1.Location = new System.Drawing.Point(517, 386);
            this.cbxShowChar1.Name = "cbxShowChar1";
            this.cbxShowChar1.Size = new System.Drawing.Size(104, 17);
            this.cbxShowChar1.TabIndex = 73;
            this.cbxShowChar1.Text = "Show characters";
            this.cbxShowChar1.UseVisualStyleBackColor = true;
            this.cbxShowChar1.CheckedChanged += new System.EventHandler(this.cbxShowChar1_CheckedChanged);
            // 
            // bttSignUp
            // 
            this.bttSignUp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.bttSignUp.BackColor = System.Drawing.Color.Chocolate;
            this.bttSignUp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttSignUp.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttSignUp.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.bttSignUp.Location = new System.Drawing.Point(505, 532);
            this.bttSignUp.Name = "bttSignUp";
            this.bttSignUp.Size = new System.Drawing.Size(128, 38);
            this.bttSignUp.TabIndex = 74;
            this.bttSignUp.Text = "Sign up";
            this.bttSignUp.UseVisualStyleBackColor = false;
            this.bttSignUp.Click += new System.EventHandler(this.bttSignUp_Click);
            // 
            // Registo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1120, 642);
            this.Controls.Add(this.bttSignUp);
            this.Controls.Add(this.cbxShowChar1);
            this.Controls.Add(this.lbPassword);
            this.Controls.Add(this.tbxPassword1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.lbConfPassword);
            this.Controls.Add(this.lbUser);
            this.Controls.Add(this.cbxShowChar2);
            this.Controls.Add(this.tbxPassword2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.lbSignIn);
            this.Controls.Add(this.tbxUser);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Registo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Registo";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Registo_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Registo_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Registo_MouseUp);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lbConfPassword;
        private System.Windows.Forms.Label lbUser;
        private System.Windows.Forms.CheckBox cbxShowChar2;
        private System.Windows.Forms.TextBox tbxPassword2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbSignIn;
        private System.Windows.Forms.TextBox tbxUser;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbPassword;
        private System.Windows.Forms.TextBox tbxPassword1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.CheckBox cbxShowChar1;
        private System.Windows.Forms.Button bttSignUp;
    }
}