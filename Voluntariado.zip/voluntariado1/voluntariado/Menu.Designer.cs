﻿namespace voluntariado
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            this.lbVoluntariado = new System.Windows.Forms.Label();
            this.bttSignIn = new System.Windows.Forms.Button();
            this.bttSignUp = new System.Windows.Forms.Button();
            this.lbWelcome = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbVoluntariado
            // 
            this.lbVoluntariado.AutoSize = true;
            this.lbVoluntariado.Font = new System.Drawing.Font("Calibri", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbVoluntariado.ForeColor = System.Drawing.Color.Chocolate;
            this.lbVoluntariado.Location = new System.Drawing.Point(232, 25);
            this.lbVoluntariado.Name = "lbVoluntariado";
            this.lbVoluntariado.Size = new System.Drawing.Size(337, 78);
            this.lbVoluntariado.TabIndex = 0;
            this.lbVoluntariado.Text = "Voluntarius";
            // 
            // bttSignIn
            // 
            this.bttSignIn.BackColor = System.Drawing.Color.Chocolate;
            this.bttSignIn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttSignIn.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttSignIn.ForeColor = System.Drawing.Color.White;
            this.bttSignIn.Location = new System.Drawing.Point(298, 239);
            this.bttSignIn.Name = "bttSignIn";
            this.bttSignIn.Size = new System.Drawing.Size(204, 60);
            this.bttSignIn.TabIndex = 1;
            this.bttSignIn.Text = "Sign In";
            this.bttSignIn.UseVisualStyleBackColor = false;
            this.bttSignIn.Click += new System.EventHandler(this.bttSignIn_Click);
            // 
            // bttSignUp
            // 
            this.bttSignUp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttSignUp.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttSignUp.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.bttSignUp.Location = new System.Drawing.Point(338, 312);
            this.bttSignUp.Name = "bttSignUp";
            this.bttSignUp.Size = new System.Drawing.Size(124, 44);
            this.bttSignUp.TabIndex = 2;
            this.bttSignUp.Text = "Sign Up";
            this.bttSignUp.UseVisualStyleBackColor = true;
            this.bttSignUp.Click += new System.EventHandler(this.bttSignUp_Click);
            // 
            // lbWelcome
            // 
            this.lbWelcome.AutoSize = true;
            this.lbWelcome.Font = new System.Drawing.Font("Calibri", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbWelcome.Location = new System.Drawing.Point(330, 108);
            this.lbWelcome.Name = "lbWelcome";
            this.lbWelcome.Size = new System.Drawing.Size(141, 39);
            this.lbWelcome.TabIndex = 3;
            this.lbWelcome.Text = "Welcome";
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lbWelcome);
            this.Controls.Add(this.bttSignUp);
            this.Controls.Add(this.bttSignIn);
            this.Controls.Add(this.lbVoluntariado);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Menu_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Menu_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Menu_MouseUp);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbVoluntariado;
        private System.Windows.Forms.Button bttSignIn;
        private System.Windows.Forms.Button bttSignUp;
        private System.Windows.Forms.Label lbWelcome;
    }
}