﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace voluntariado
{
    public partial class Login : Form
    {
        private bool mouseDown;
        private Point lastLocation;

        public bool verif = false;
        public Login()
        {
            InitializeComponent();
            tbxPassword.PasswordChar = '●';
        }


        private void Login_MouseDown(object sender, MouseEventArgs e)
        {
            mouseDown = true;
            lastLocation = e.Location;

        }

        private void Login_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseDown)
            {
                this.Location = new Point(
                    (this.Location.X - lastLocation.X) + e.X, (this.Location.Y - lastLocation.Y) + e.Y);

                this.Update();
            }
        }

        private void Login_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;
        }

        private bool VerifUser()
        {
            StreamReader readLogins = new StreamReader("Logins.txt");
            while (readLogins.Peek() > 0)
            {
                string line = readLogins.ReadLine();
                string user = line.Split('|')[0].Split(':')[1];
                string pass = line.Split('|')[1].Split(' ')[1];
                user = user.Replace(" ", "");
                if (user == tbxUser.Text && pass.Equals(tbxPassword.Text, StringComparison.Ordinal) == true)
                {
                    readLogins.Close();
                    return true;
                }
            }
            readLogins.Close();
            return false;
        }

        private bool VerifWhatIsWrong()
        {
            StreamReader readLogins = new StreamReader("Logins.txt");
            while (readLogins.Peek() > 0)
            {
                string line = readLogins.ReadLine();
                string user = line.Split(':')[1].Split('|')[0];
                user = user.Replace(" ", "");
                if (user == tbxUser.Text)
                {
                    readLogins.Close();
                    return true;
                }
            }
            readLogins.Close();
            return false;
        }



        private void cbxShowChar_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxShowChar.Checked)
            {
                tbxPassword.PasswordChar = '\0';
            }
            else
            {
                tbxPassword.PasswordChar = '●';
            }
        }

        private void bttSignIn_Click(object sender, EventArgs e)
        {
            if(VerifUser())
            {
                verif = true;
                this.Close();
            }
            else
            {
                if(VerifWhatIsWrong()) //Verificar se o Usuario existe
                {
                    //Dar um errorProvider no User

                }
                else
                {
                    //Dar um errorProvider na Password

                }
            }
        }

        private void lbRegisto_Click(object sender, EventArgs e)
        {
            this.Hide();
            Registo registo = new Registo();
            registo.ShowDialog();
            if(registo.verif)
            {
                verif = true;
                this.Close();
            }
            else
            {
                this.Show();
            }
        }
    }
}
