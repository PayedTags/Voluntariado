﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Xml;
using System.Xml.Linq;
    namespace voluntariado
{
    public partial class Voluntariado : Form
    {
        public static ColUtilizador Users = new ColUtilizador();
        public static bool Criado = false;
        private bool mouseDown;
        private Point lastLocation;

        public Voluntariado()
        {
            InitializeComponent();
            if (!File.Exists("Contas.xml"))
            {
                XmlWriterSettings settings = new XmlWriterSettings();
                settings.Indent = true;
                XmlWriter writer = XmlWriter.Create("Contas.xml", settings);
                writer.WriteStartDocument();
                writer.WriteComment("Contas dos utilizadores");
                writer.WriteStartElement("Contas");
                writer.WriteEndDocument();
                writer.Close();
            }
            else
            {
                Criado = true;
            }
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            mouseDown = true;
            lastLocation = e.Location;

        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseDown)
            {
                this.Location = new Point(
                    (this.Location.X - lastLocation.X) + e.X, (this.Location.Y - lastLocation.Y) + e.Y);

                this.Update();
            }
        }

        private void criarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CriarUtilizador crUt = new CriarUtilizador();
            crUt.ShowDialog();
        }

        private void editarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EditarDados edUt = new EditarDados();
            edUt.ShowDialog();
        }
        public static void AddXml(Utilizador user)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load("Contas.xml");

            XmlNode User = doc.CreateElement("User");
            XmlNode NIF = doc.CreateElement("NIF");
            XmlNode IRS = doc.CreateElement("IRS");
            XmlNode Nome = doc.CreateElement("Nome");
            XmlNode Localidade = doc.CreateElement("Localidade");
            XmlNode Morada = doc.CreateElement("Morada");
            XmlNode CodigoPostal = doc.CreateElement("CodigoPostal");
            XmlNode Contacto = doc.CreateElement("Contacto");
            XmlNode Email = doc.CreateElement("Email");
            XmlNode WhatsApp = doc.CreateElement("WhatsApp");
            XmlNode Tipo = doc.CreateElement("Tipo");
            XmlNode Password = doc.CreateElement("Password");

            NIF.InnerText = user.NIF.ToString();
            User.AppendChild(NIF);

            IRS.InnerText = user.IRS.ToString();
            User.AppendChild(IRS);

            Nome.InnerText = user.Nome;
            User.AppendChild(Nome);

            Localidade.InnerText = user.Localidade;
            User.AppendChild(Localidade);

            Morada.InnerText = user.Morada;
            User.AppendChild(Morada);

            Contacto.InnerText = user.Contacto;
            User.AppendChild(Contacto);

            CodigoPostal.InnerText = user.CodigoPostal;
            User.AppendChild(CodigoPostal);

            Email.InnerText = user.Email;
            User.AppendChild(Email);

            WhatsApp.InnerText = user.WhatsApp;
            User.AppendChild(WhatsApp);

            Password.InnerText = user.Password;
            User.AppendChild(Password);

            Tipo.InnerText = user.Tipo;
            User.AppendChild(Tipo);

            doc.DocumentElement.AppendChild(User);

            doc.Save("Contas.xml");
        }

        public void organizaLista()
        {
            XmlDocument users = new XmlDocument();
            users.Load("Contas.xml");

            foreach(XmlNode node in users.DocumentElement)
            {
                Utilizador user = new Utilizador();
                foreach (XmlNode child in users.ChildNodes)
                {
                    switch (child.Name)
                    {
                        case "NIF":
                            user.NIF = Convert.ToInt32(child.Value);
                            break;
                        case "IRS":
                            user.IRS = Convert.ToInt32(child.Value);
                            break;
                        case "Nome":
                            user.Nome = Convert.ToInt32(child.Value);
                            break;
                        case "Localidade":
                            user.Localidade = Convert.ToInt32(child.Value);
                            break;
                        case "Morada":
                            user.Morada = Convert.ToInt32(child.Value);
                            break;
                        case "CodigoPostal":
                            user.CodigoPostal = Convert.ToInt32(child.Value);
                            break;
                        case "Email":
                            user.Email = Convert.ToInt32(child.Value);
                            break;

                        case "Contacto":
                            user.Contacto = Convert.ToInt32(child.Value);
                            break;

                        case "WhatsApp":
                            user.WhatsApp = Convert.ToInt32(child.Value);
                            break;

                        case "Tipo":
                            user.Tipo = Convert.ToInt32(child.Value);
                            break;

                        case "Password":
                            user.Password = Convert.ToInt32(child.Value);
                            break;
                    }
                }
                Users.AdicionarUtilizador(user);
            }
        }
    }
}
