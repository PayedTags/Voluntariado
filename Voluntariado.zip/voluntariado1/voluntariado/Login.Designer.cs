﻿namespace voluntariado
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            this.lbRegisto = new System.Windows.Forms.Label();
            this.lbForgot = new System.Windows.Forms.Label();
            this.lbPassword = new System.Windows.Forms.Label();
            this.lbUser = new System.Windows.Forms.Label();
            this.bttSignIn = new System.Windows.Forms.Button();
            this.cbxShowChar = new System.Windows.Forms.CheckBox();
            this.tbxPassword = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbSignIn = new System.Windows.Forms.Label();
            this.tbxUser = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // lbRegisto
            // 
            this.lbRegisto.AutoSize = true;
            this.lbRegisto.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbRegisto.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lbRegisto.Location = new System.Drawing.Point(526, 553);
            this.lbRegisto.Name = "lbRegisto";
            this.lbRegisto.Size = new System.Drawing.Size(69, 15);
            this.lbRegisto.TabIndex = 58;
            this.lbRegisto.Text = "Criar conta";
            this.lbRegisto.Click += new System.EventHandler(this.lbRegisto_Click);
            // 
            // lbForgot
            // 
            this.lbForgot.AutoSize = true;
            this.lbForgot.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbForgot.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbForgot.Location = new System.Drawing.Point(508, 504);
            this.lbForgot.Name = "lbForgot";
            this.lbForgot.Size = new System.Drawing.Size(105, 15);
            this.lbForgot.TabIndex = 57;
            this.lbForgot.Text = "Forgot password?";
            // 
            // lbPassword
            // 
            this.lbPassword.AutoSize = true;
            this.lbPassword.BackColor = System.Drawing.Color.Transparent;
            this.lbPassword.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPassword.ForeColor = System.Drawing.Color.Gray;
            this.lbPassword.Location = new System.Drawing.Point(527, 354);
            this.lbPassword.Name = "lbPassword";
            this.lbPassword.Size = new System.Drawing.Size(67, 18);
            this.lbPassword.TabIndex = 56;
            this.lbPassword.Text = "Password";
            // 
            // lbUser
            // 
            this.lbUser.AutoSize = true;
            this.lbUser.BackColor = System.Drawing.Color.Transparent;
            this.lbUser.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbUser.ForeColor = System.Drawing.Color.Gray;
            this.lbUser.Location = new System.Drawing.Point(525, 281);
            this.lbUser.Name = "lbUser";
            this.lbUser.Size = new System.Drawing.Size(71, 18);
            this.lbUser.TabIndex = 55;
            this.lbUser.Text = "Username";
            // 
            // bttSignIn
            // 
            this.bttSignIn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.bttSignIn.BackColor = System.Drawing.Color.Chocolate;
            this.bttSignIn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttSignIn.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttSignIn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.bttSignIn.Location = new System.Drawing.Point(496, 463);
            this.bttSignIn.Name = "bttSignIn";
            this.bttSignIn.Size = new System.Drawing.Size(128, 38);
            this.bttSignIn.TabIndex = 54;
            this.bttSignIn.Text = "Sign in";
            this.bttSignIn.UseVisualStyleBackColor = false;
            this.bttSignIn.Click += new System.EventHandler(this.bttSignIn_Click);
            // 
            // cbxShowChar
            // 
            this.cbxShowChar.AutoSize = true;
            this.cbxShowChar.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxShowChar.Location = new System.Drawing.Point(508, 416);
            this.cbxShowChar.Name = "cbxShowChar";
            this.cbxShowChar.Size = new System.Drawing.Size(104, 17);
            this.cbxShowChar.TabIndex = 53;
            this.cbxShowChar.Text = "Show characters";
            this.cbxShowChar.UseVisualStyleBackColor = true;
            this.cbxShowChar.CheckedChanged += new System.EventHandler(this.cbxShowChar_CheckedChanged);
            // 
            // tbxPassword
            // 
            this.tbxPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxPassword.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxPassword.Location = new System.Drawing.Point(402, 383);
            this.tbxPassword.Name = "tbxPassword";
            this.tbxPassword.Size = new System.Drawing.Size(290, 24);
            this.tbxPassword.TabIndex = 52;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel2.Location = new System.Drawing.Point(402, 409);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(317, 1);
            this.panel2.TabIndex = 51;
            // 
            // lbSignIn
            // 
            this.lbSignIn.AutoSize = true;
            this.lbSignIn.Font = new System.Drawing.Font("Calibri Light", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSignIn.ForeColor = System.Drawing.Color.Chocolate;
            this.lbSignIn.Location = new System.Drawing.Point(460, 74);
            this.lbSignIn.Name = "lbSignIn";
            this.lbSignIn.Size = new System.Drawing.Size(200, 78);
            this.lbSignIn.TabIndex = 50;
            this.lbSignIn.Text = "Sign in";
            // 
            // tbxUser
            // 
            this.tbxUser.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxUser.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxUser.Location = new System.Drawing.Point(402, 302);
            this.tbxUser.Name = "tbxUser";
            this.tbxUser.Size = new System.Drawing.Size(290, 24);
            this.tbxUser.TabIndex = 49;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel1.Location = new System.Drawing.Point(402, 328);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(317, 1);
            this.panel1.TabIndex = 48;
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1120, 642);
            this.Controls.Add(this.lbRegisto);
            this.Controls.Add(this.lbForgot);
            this.Controls.Add(this.lbPassword);
            this.Controls.Add(this.lbUser);
            this.Controls.Add(this.bttSignIn);
            this.Controls.Add(this.cbxShowChar);
            this.Controls.Add(this.tbxPassword);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.lbSignIn);
            this.Controls.Add(this.tbxUser);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Login_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Login_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Login_MouseUp);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbRegisto;
        private System.Windows.Forms.Label lbForgot;
        private System.Windows.Forms.Label lbPassword;
        private System.Windows.Forms.Label lbUser;
        private System.Windows.Forms.Button bttSignIn;
        private System.Windows.Forms.CheckBox cbxShowChar;
        private System.Windows.Forms.TextBox tbxPassword;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbSignIn;
        private System.Windows.Forms.TextBox tbxUser;
        private System.Windows.Forms.Panel panel1;
    }
}