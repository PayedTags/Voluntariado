﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace voluntariado
{
    public partial class EditarDados : Form
    {
        public EditarDados()
        {
            InitializeComponent();
            tbxPassword.PasswordChar = '●';
            tbxPassword2.PasswordChar = '●';
        }

        private void cbxShowChar_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxShowChar.Checked)
            {
                tbxPassword.PasswordChar = '\0';
            }
            else
            {
                tbxPassword.PasswordChar = '●';
            }
        }

        private void cbxShowChar2_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxShowChar2.Checked)
            {
                tbxPassword2.PasswordChar = '\0';
            }
            else
            {
                tbxPassword2.PasswordChar = '●';
            }
        }
    }
}
