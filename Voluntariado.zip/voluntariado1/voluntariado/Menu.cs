﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace voluntariado
{
    public partial class Menu : Form
    {
        private bool mouseDown;
        private Point lastLocation;

        public bool verif = false;
        public Menu()
        {
            InitializeComponent();
        }

        private void bttSignIn_Click(object sender, EventArgs e)
        {
            this.Hide();

            Login login = new Login();
            login.ShowDialog();
            if(login.verif)
            {
                verif = true;
                this.Close();
            }
            else
            {
                this.Show();
            }
        }

        private void bttSignUp_Click(object sender, EventArgs e)
        {
            this.Hide();

            Registo registo = new Registo();
            registo.ShowDialog();
            if (registo.verif)
            {
                verif = true;
                this.Close();
            }
            else
            {
                this.Show();
            }
        }

        private void Menu_MouseDown(object sender, MouseEventArgs e)
        {
            mouseDown = true;
            lastLocation = e.Location;
        }

        private void Menu_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;
        }

        private void Menu_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseDown)
            {
                this.Location = new Point(
                    (this.Location.X - lastLocation.X) + e.X, (this.Location.Y - lastLocation.Y) + e.Y);

                this.Update();
            }
        }
    }
}
