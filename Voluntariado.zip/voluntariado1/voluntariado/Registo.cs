﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace voluntariado
{
    public partial class Registo : Form
    {
        private bool mouseDown;
        private Point lastLocation;

        public bool verif = false;

        private string path = "Logins.txt";
        public Registo()
        {
            InitializeComponent();
            tbxPassword2.PasswordChar = '●';
            tbxPassword1.PasswordChar = '●';
        }

        private void Registo_MouseDown(object sender, MouseEventArgs e)
        {
            mouseDown = true;
            lastLocation = e.Location;
        }

        private void Registo_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseDown)
            {
                this.Location = new Point(
                    (this.Location.X - lastLocation.X) + e.X, (this.Location.Y - lastLocation.Y) + e.Y);

                this.Update();
            }
        }

        private void Registo_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;
        }

        private void cbxShowChar1_CheckedChanged(object sender, EventArgs e)
        {
            if(cbxShowChar1.Checked)
            {
                tbxPassword1.PasswordChar = '\0' ;
            }
            else
            {
                tbxPassword1.PasswordChar = '●';
            }
        }

        private void cbxShowChar2_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxShowChar1.Checked)
            {
                tbxPassword2.PasswordChar = '\0';
            }
            else
            {
                tbxPassword2.PasswordChar = '●';
            }
        }

        private void bttSignUp_Click(object sender, EventArgs e)
        {
            string user = tbxUser.Text;
            string pass = tbxPassword1.Text;
            string confirm = tbxPassword2.Text;
            if (confirm.Equals(pass, StringComparison.Ordinal))
            {
                if (VerifUser())
                {
                    MessageBox.Show("Erro: Utilizador ja criado!!");
                }
                else
                {
                    string completo = "User: " + user + "|" + "PassWord: " + pass;
                    FileStream fs = new FileStream(path, FileMode.Append, FileAccess.Write);
                    StreamWriter userWriter = new StreamWriter(fs);
                    userWriter.WriteLine(completo);
                    userWriter.Close();
                    MessageBox.Show("Utilizador foi criado!!");
                }

            }
            else
            {
                MessageBox.Show("Erro: Password Incorreta!!");
            }
        }

        private bool VerifUser()
        {
            StreamReader readLogins = new StreamReader(path);
            while (readLogins.Peek() > 0)
            {
                string line = readLogins.ReadLine();
                string user = line.Split(':')[1].Split('|')[0];
                user = user.Replace(" ", "");
                if (user == tbxUser.Text)
                {
                    readLogins.Close();
                    return true;
                }
            }
            readLogins.Close();
            return false;
        }
    }
}
