﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace voluntariado
{
    public partial class CriarUtilizador : Form
    {
        public Utilizador User;
        public CriarUtilizador()
        {
            InitializeComponent();
            tbxPassword.PasswordChar = '●';
        }

        private void cbxShowChar_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxShowChar.Checked)
            {
                tbxPassword.PasswordChar = '\0';
            }
            else
            {
                tbxPassword.PasswordChar = '●';
            }
        }

        private void bttCriar_Click(object sender, EventArgs e)
        {
            int NIF;
            int IRS;
            string Nome;
            string Localidade;
            string Morada;
            string CodigoPostal;
            string Contacto;
            string Email;
            string WhatsApp;
            string Tipo;
            string Password;
            User = new Utilizador();
            try
            {
                
                NIF = Convert.ToInt32(tbxNIF.Text);
                IRS = Convert.ToInt32(tbxIRS.Text);
                Nome = tbxNome.Text;
                Localidade = tbxLocalidade.Text;
                Morada = tbxMorada.Text;
                CodigoPostal = tbxCodigoPostal.Text;
                Contacto = tbxContacto.Text;
                Email = tbxEmail.Text;
                WhatsApp = tbxWhatsApp.Text;
                Password = tbxPassword.Text;
                if (rbttVoluntario.Checked)
                    Tipo = "Voluntario";

                if (rbttCliente.Checked)
                    Tipo = "Cliente";


                User.NIF = NIF;
                User.IRS = IRS;
                User.Nome = Nome;
                User.Localidade = Localidade;
                User.Morada = Morada;
                User.CodigoPostal = CodigoPostal;
                User.Contacto = Contacto;
                User.Email = Email;
                User.WhatsApp = WhatsApp;
                User.Password = Password;

                Voluntariado.Users.AdicionarUtilizador(User);
                Voluntariado.AddXml(User);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
