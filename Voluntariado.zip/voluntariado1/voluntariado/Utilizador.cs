﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace voluntariado
{
   public class Utilizador
    {
        #region PropriedadesAutomaticas
        public int NIF { get; set; }
        public int IRS { get; set; }
        public string Nome { get; set; }
        public string Localidade { get; set; }
        public string Morada { get; set; }
        public string CodigoPostal { get; set; }
        public string Contacto { get; set; }
        public string Email { get; set; }
        public string WhatsApp { get; set; }
        public string Tipo { get; set; }
        public string Password { get; set; }
        #endregion

    }
}
