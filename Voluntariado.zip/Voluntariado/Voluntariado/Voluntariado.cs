﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.IO;

namespace Voluntariado
{
    public partial class Voluntariado : Form
    {
        public Voluntariado()
        {

            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void asdToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void criarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormCriarUtilizador CriarUtilizador = new FormCriarUtilizador();
            CriarUtilizador.Show();
        }
    }
}
