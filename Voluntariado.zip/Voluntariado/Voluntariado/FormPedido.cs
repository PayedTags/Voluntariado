﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Voluntariado
{
    public partial class FormPedido : Form
    {
        public FormPedido()
        {
            InitializeComponent();
        }

        private void btn_Pedir_Click(object sender, EventArgs e)
        {
            StreamWriter smWriter = new StreamWriter("Pedidos.txt");
            
            smWriter.WriteLine("Descrição: " + txtbox_Descrição.Text);
            smWriter.WriteLine("Areas: ");
            if (checkBox1.Checked)
                smWriter.WriteLine(checkBox1.Text);
            if (checkBox1.Checked)
                smWriter.WriteLine(checkBox1.Text);
            if (checkBox1.Checked)
                smWriter.WriteLine(checkBox1.Text);
            if (checkBox1.Checked)
                smWriter.WriteLine(checkBox1.Text);
            if (checkBox1.Checked)
                smWriter.WriteLine(checkBox1.Text);
            if (checkBox1.Checked)
                smWriter.WriteLine(checkBox1.Text);

        }
    }
}
