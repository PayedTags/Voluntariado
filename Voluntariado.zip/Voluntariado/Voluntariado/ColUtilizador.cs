﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace Voluntariado
{
    public class ColUtilizador : Collection<Utilizador>
    {
        public bool AdicionarUtilizador(Utilizador utilizador)
        {
            if (VerificaRepetido(utilizador.NIF))
            {
                return false; 
            }
            base.Add(utilizador);
            return true;
        }

        public bool VerificaRepetido(int Codigo)
        {
            for (int i = 0; i < this.Count(); i++)
            {
                if (this[i].NIF == Codigo)
                    return true;
            }
            return false;
        }
    }
}
